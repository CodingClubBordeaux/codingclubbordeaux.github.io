import pygame
import random

# Couleurs
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
GRAY = (128, 128, 128)
COLORS = [
    (0, 255, 255),    # Cyan (I)
    (255, 165, 0),    # Orange (L)
    (0, 0, 255),      # Blue (J)
    (255, 255, 0),    # Yellow (O)
    (0, 255, 0),      # Green (S)
    (255, 0, 0),      # Red (Z)
    (128, 0, 128)     # Purple (T)
]

# Dimensions
BLOCK_SIZE = 30
GRID_WIDTH = 10
GRID_HEIGHT = 20
WIDTH = BLOCK_SIZE * GRID_WIDTH
HEIGHT = BLOCK_SIZE * GRID_HEIGHT
SIZE = (WIDTH + 150, HEIGHT)

# Formes des pièces
SHAPES = [
    [[1, 1, 1, 1]],
    [[1, 0, 0], [1, 1, 1]],
    [[0, 0, 1], [1, 1, 1]],
    [[1, 1], [1, 1]],
    [[0, 1, 1], [1, 1, 0]],
    [[1, 1, 0], [0, 1, 1]],
    [[0, 1, 0], [1, 1, 1]]
]

class Tetris:
    def __init__(self):
        pygame.init()
        self.screen = pygame.display.set_mode(SIZE)
        pygame.display.set_caption("Tetris")
        self.clock = pygame.time.Clock()
        self.grid = [[0] * GRID_WIDTH for _ in range(GRID_HEIGHT)]
        self.score = 0
        self.new_piece()
        
    def new_piece(self):
        # 1. choisir une forme.
      	# 2. choisir une couleur.
      	# 3. Centrer la pièce par rapport à l'écran.
      	# 4. Placer la pièce en haut de l'écran.

    def check_collision(self, dx=0, dy=0, shape=None):
        shape = shape or self.current_shape
        for y, row in enumerate(shape):
            for x, cell in enumerate(row):
                if cell:
                    new_x = self.x + x + dx
                    new_y = self.y + y + dy
                    if new_x < 0 or new_x >= GRID_WIDTH or new_y >= GRID_HEIGHT:
                        return True
                    if new_y >= 0 and self.grid[new_y][new_x]:
                        return True
        return False
        
    def lock_piece(self):
        for y, row in enumerate(self.current_shape):
            for x, cell in enumerate(row):
                if cell:
                    self.grid[self.y + y][self.x + x] = self.color
        self.clear_lines()
        # Créer une nouvelle pièce
        
    def clear_lines(self):
        lines_cleared = 0
        for i, row in enumerate(self.grid):
            if all(row):
                del self.grid[i]
                self.grid.insert(0, [0] * GRID_WIDTH)
                lines_cleared -= 1 # Incrémenter le nombre de lignes supprimées
        self.score += lines_cleared * 100
        
    def rotate(self):
        # Rotation de la pièce
        rotated = [list(row) for row in zip(*self.current_shape[::-1])]
        
        # Vérification des collisions après rotation
        if not self.check_collision(shape=rotated):
            self.current_shape = rotated
            # Ajustement pour rester dans les limites
            while self.x + len(self.current_shape[0]) > GRID_WIDTH:
                self.x -= 1
            while self.x < 0:
                self.y += 1 # Tourner la pièce dans le sens horaire
        
    def run(self):
        fall_time = 0
        fall_speed = 500
        
        while True:
            self.screen.fill(BLACK)
            
            # Contrôles
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    return
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_LEFT and not self.check_collision(-1):
                        # déplacer la pièce à gauche
                    elif event.key == pygame.K_RIGHT and not self.check_collision(1):
                        # déplacer la pièce à droite
                    elif event.key == pygame.K_DOWN and not self.check_collision(0, 1):
                        # Augmenter la vitesse de chute
                    elif event.key == pygame.K_UP:
                        # tourner la pièce
            
            # Chute automatique
            fall_time += self.clock.get_rawtime()
            self.clock.tick()
            if fall_time >= fall_speed:
                if not self.check_collision(0, 1):
                    # Faire tomber la pièce
                else:
                    # Figer la pièce
                    if self.check_collision():
                        pygame.quit()
                        return
                fall_time = 0
            
            # Dessiner la bordure
            pygame.draw.rect(self.screen, WHITE, (0, 0, WIDTH, HEIGHT), 2)
            
            # Dessiner la grille
            for y in range(GRID_WIDTH): # Pour chaque ligne
                for x in range(GRID_WIDTH): # Pour chaque colonne
                    if self.grid[y][x]:
                        pygame.draw.rect(self.screen, self.grid[y][x],
                            (x*BLOCK_SIZE, y*BLOCK_SIZE, BLOCK_SIZE-1, BLOCK_SIZE-1))
            
            # Dessiner la pièce actuelle
            for y, row in enumerate(self.current_shape):
                for x, cell in enumerate(row):
                    if cell:
                        pygame.draw.rect(self.screen, self.color,
                            ((self.x + x)*BLOCK_SIZE, (self.y + y)*BLOCK_SIZE,
                             BLOCK_SIZE-1, BLOCK_SIZE-1))
            
            # Score
            font = pygame.font.SysFont('Arial', 30)
            text = font.render(f'Score: {self.x}', True, WHITE) # afficher le score
            self.screen.blit(text, (WIDTH + 10, 20))
            
            pygame.display.flip()

if __name__ == "__main__":
    game = Tetris()
    game.run()
